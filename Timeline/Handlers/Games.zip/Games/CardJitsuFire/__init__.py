from Timeline.Server.Constants import TIMELINE_LOGGER, LOGIN_SERVER, WORLD_SERVER
from Timeline import Username, Password, Inventory
from Timeline.Utils.Events import Event, PacketEventHandler, GeneralEvent
from Timeline.Server.Room import Game, Place, Multiplayer
from Timeline.Handlers.Games.WaddleHandler import Waddle
from Timeline.Handlers.Games.CardJitsu import Card

from twisted.internet.defer import inlineCallbacks, returnValue

from collections import deque
import logging
from time import time
from random import choice, shuffle, sample

logger = logging.getLogger(TIMELINE_LOGGER)

CJ_MATS = {300: 2, 301: 2, 302: 3, 303: 4}

class CardJitsuGame(Multiplayer):
	waddle = -1 # Waddle id

	def __init__(self, rh):
		super(CardJitsuGame, self).__init__(rh, 997, "Fire", "Game: Card Jitsu Fire", 4, False, False, None)
		self.Playing = [None, None, None, None]
		self.GameStarted = False
		self.Player = None

	def gameOver(self, playerLeft = None, client = None):
		pass

	def play(self, client, param):
		if not self.GameStarted or self.Player is not client:
			return client.send('e', 'ABCDE-ee-FU')

		print param

	def onAdd(self, client):
		client.penguin.game = self
		client.penguin.room = self
		client.penguin.waddling = False
		client.penguin.playing = True

	def joinGame(self, client):
		if client not in self:
			return

		client.penguin.game = client.penguin.room = self

		self.Playing[client['game_index']] = client
		client.send('jz', client['game_index'], client['nickname'], client['color'], user['ninjaHandler'].ninja.belt)
		self.updateGame()

		if None not in self.Playing[:CJ_MATS[self.waddle]]:
			self.startGame()

	def startGame(self):
		if self.GameStarted:
			return

		self.Playing = self[:CJ_MATS[self.waddle]]

		self.GameStarted = True
		self.Player = self.Playing[1]

		self.setupCards()
		self.send('sz', 'Fire')


	def updateGame(self):
		uzString = list()
		for i in range(CJ_MATS[self.waddle]):
			user = self.Playing[i]
			if user is None:
				continue
			# seat|nickname|peng_color|belt
			uzString.append('|'.join(map(str, [i, user['nickname'], user['color'], user['ninjaHandler'].ninja.belt])))

		self.send('uz', len(uzString), '%'.join(uzString))

	def getGame(self, client):
		client.send('gz', self)

	def __str__(self):
		return '{}%{}'.format(CJ_MATS[self.waddle], len([k for k in self.Playing if k is not None]))

	def onRemove(self, client):
		client.penguin.game_index = client.penguin.game = None
		client.penguin.waddling = client.penguin.playing = False

		if self.GameStarted:
			self.gameOver(client)



class CJMat(Waddle):
	stamp = 32
	room = None
	game = CardJitsuGame

	waddles = 2 # No of players waddling.
	waddle = None # waddle id

	def __init__(self, *a, **kw):
		super(CJMat, self).__init__(*a, **kw)

		self.stamp = self.roomHandler.getRoomByExtId(997).stamp_id
		self.room = self.roomHandler.getRoomByExtId(812)

	# CJMS
	def startWaddle(self):
		clients = list(self[:self.waddles])
		cjms = [0]*self.waddles*3 # no of players * 3

		for i in range(self.waddles):
			cjms[i + 0 * self.waddles] = clients[i]['color']
			cjms[i + 1 * self.waddles] = clients[i]['ninjaHandler'].ninja.belt
			cjms[i + 2 * self.waddles] = clients[i]['id']

		for c in clients:
			c.send('cjms', self.waddle, 997, -997, 2, *cjms)
			c.penguin.game_index = clients.index(c)

		super(CJMat, self).startWaddle()